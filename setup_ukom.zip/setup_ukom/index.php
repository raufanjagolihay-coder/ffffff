<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons/bootstrap-icons.css">
</head>

<body>
    <!-- Awal Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top shadow">
        <div class="container">
            <a href="" class="navbar-brand fw-bold">Asis</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a href="" class="nav-link">Fitur</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Tentang</a></li>
                    <li class="nav-item"><a href="" class="btn btn-light text-primary">Masuk</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- AKhir Navbar -->

    <section class="hero text-center text-light bg-primary min-vh-100 d-flex align-items-center pt-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-12">
                    <h1 class="display-4 fw-bold mt-5">Aspirasi Siswa</h1>
                    <p class="lead mt-3">Aplikasi yang menampung aspirasi siswa terkait sarana dan prasarana sekolah, guna membangun dan melengkapi fasilitas yang dibutuhkan oleh siswa, demi menjaga kualitas Sekolah</p>
                    <a href="login" class="btn btn-light btn-lg">Buat Aspirasimu Sekarang <i class="bi bi-arrow-right"></i></a>
                </div>
            </div>
        </div>
    </section>

</body>

</html>