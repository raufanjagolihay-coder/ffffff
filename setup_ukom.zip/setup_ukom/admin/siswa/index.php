<?php
session_start();

//Pengecekan Jika tidak ada Session role atau rolenya selain admin
//Maka di kick ke halaman landing page
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../../index.php");
}

$_SESSION['menu'] = "siswa";
//Setup untuk koneksi, baseurl dan menu admin
include "../../includes/koneksi.php";
include "../../includes/baseurl.php";
include "../../includes/navbar_admin.php";

$query = "SELECT * FROM tb_kelas WHERE nama_kelas != 'admin'";
$sql_eksekusi = mysqli_query($koneksi, $query);
?>

<main class="flex-fill">
    <div class="container py-3">
        <h5>Manajemen Siswa</h5>
        <hr>

        <!-- TOMBOL TAMBAH -->
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#ModalTambah">
            <i class="bi bi-plus-lg"></i>Tambah Siswa
        </button>

        <!-- Modal -->
        <div class="modal fade" id="ModalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="input_siswa.php" method="post">
                        <div class="modal-header bg-success text-light">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Tambahkan Siswa</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <!-- input group nis -->
                            <div class="row my-2">
                                <div class="col-lg-12">
                                    <label for="">NIS (nomor induk siswa)</label>
                                    <input type="text" name="nis" id="" class="form-control">
                                </div>
                            </div>
                            <!-- end input group nis -->

                            <!-- input group nama siswa -->
                            <div class="row my-2">
                                <div class="col-lg-12">
                                    <label for="">Nama Siswa</label>
                                    <input type="text" name="nama" id="" class="form-control">
                                </div>
                            </div>
                            <!-- end input group nama siswa -->

                            <!-- input group nama email -->
                            <div class="row my-2">
                                <div class="col-lg-12">
                                    <label for="">Email</label>
                                    <input type="email" name="email" id="" class="form-control">
                                </div>
                            </div>
                            <!-- end input group nama email -->

                            <!-- input group nama email -->
                            <div class="row my-2">
                                <div class="col-lg-12">
                                    <label for="">Password</label>
                                    <input type="password" name="password" id="" class="form-control">
                                </div>
                            </div>
                            <!-- end input group nama email -->

                            <!-- input group nama jenis kelamin-->
                            <div class="row my-2">
                                <div class="col-lg-12">
                                    <label for="">Jenis Kelamin</label>
                                </div>
                                <div class="col-lg-12 d-flex">
                                    <div class="form-check me-3">
                                        <input class="form-check-input" value="L" type="radio" name="jenis_kelamin" id="radioDefault1">
                                        <label class="form-check-label" for="radioDefault1">
                                            Laki-Laki
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" value="P" type="radio" name="jenis_kelamin" id="radioDefault2">
                                        <label class="form-check-label" for="radioDefault2">
                                            Perempuan
                                        </label>
                                    </div>
                                </div>
                            </div>
                            <!-- end input group nama jenis kelamin-->

                            <!-- input group kelas -->
                            <div class="row my-2">
                                <div class="col-lg-12">
                                    <label for="">Kelas</label>
                                </div>
                                <div class="col-lg-12">
                                    <select name="id_kelas" class="form-select" aria-label="Default select example">
                                        <option selected>Pilih Kelas</option>
                                        <?php

                                        while ($data_kelas = mysqli_fetch_array($sql_eksekusi)) {
                                        ?>
                                            <option value="<?= $data_kelas['id_kelas']; ?>">
                                                <?= $data_kelas['nama_kelas']; ?>
                                            </option>
                                        <?php } ?>
                                    </select>
                                </div>
                            </div>
                            <!-- end input group kelas -->
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <input type="submit" value="Tambah" class="btn btn-success">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- AKHIR TOMBOL TAMBAH -->

        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>No.</th>
                    <th>NIS</th>
                    <th>Nama Siswa</th>
                    <th>Email</th>
                    <th>Jenis Kelamin</th>
                    <th>Kelas</th>
                    <th>Peran</th>
                    <th>Waktu Dibuat</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM tb_user as tbu 
                INNER JOIN tb_kelas = tbk
                ON tbu.id_kelas = tbk.id_kelas 
                WHERE role != 'admin'";
                $sql_eksekusi_siswa = mysqli_query($koneksi, $sql);
                $no = 1;
                while ($data = mysqli_fetch_array($sql_eksekusi_siswa)) {
                ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $data['nis']; ?></td>
                        <td><?= $data['nama']; ?></td>
                        <td><?= $data['email']; ?></td>
                        <td><?= $data['jenis_kelamin']; ?></td>
                        <td><?= $data['nama_kelas']; ?></td>
                        <td><?= $data['role']; ?></td>
                        <td><?= $data['created_at']; ?></td>
                        <td>
                            <!-- modal ubah  -->
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-sm btn-warning text-light " data-bs-toggle="modal" data-bs-target="#ModalUbah<?= $no; ?>">
                                <i class="bi bi-pencil-square"></i>
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="ModalUbah<?= $no; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="update_siswa.php" method="post">
                                            <div class="modal-header bg-warning text-light">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Ubah Siswa</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">

                                                <!-- input group id kelas -->
                                                <div class="row my-2">
                                                    <div class="col-lg-12">
                                                        <!-- <label for="">ID Siswa</label> -->
                                                        <input type="hidden" name="id_siswa" id="" class="form-control" value="<?= $data['id_user']; ?>">
                                                    </div>
                                                </div>
                                                <!-- end input group id kelas -->

                                                <!-- input group nis -->
                                                <div class="row my-2">
                                                    <div class="col-lg-12">
                                                        <label for="">NIS (nomor induk siswa)</label>
                                                        <h2><?= $data['nis']; ?></h2>
                                                        <input type="hidden" name="nis" id="" class="form-control" value="<?= $data['nis']; ?>">
                                                    </div>
                                                </div>
                                                <!-- end input group nis -->

                                                <!-- input group nama siswa -->
                                                <div class="row my-2">
                                                    <div class="col-lg-12">
                                                        <label for="">Nama Siswa</label>
                                                        <input type="text" name="nama" id="" class="form-control" value="<?= $data['nama']; ?>">
                                                    </div>
                                                </div>
                                                <!-- end input group nama siswa -->

                                                <!-- input group nama email -->
                                                <div class="row my-2">
                                                    <div class="col-lg-12">
                                                        <label for="">Email</label>
                                                        <input type="email" name="email" id="" class="form-control" value="<?= $data['email']; ?>">
                                                    </div>
                                                </div>
                                                <!-- end input group nama email -->

                                                <!-- input group nama email -->
                                                <div class="row my-2">
                                                    <div class="col-lg-12">
                                                        <label for="">Password</label>
                                                        <input type="password" name="password" id="" class="form-control" placeholder="Sandi Tidak Diubah" >
                                                        <input type="hidden" name="password_lama" id="" value="<?= $data['password'] ?>">
                                                        <p class="text-danger fs-7">*Biarkan Tetap Kosong, Bila Katasandi Tidak Ingin Diubah.</p>
                                                    </div>
                                                </div>
                                                <!-- end input group nama email -->

                                                <!-- input group nama jenis kelamin-->
                                                <div class="row my-2">
                                                    <div class="col-lg-12">
                                                        <label for="">Jenis Kelamin</label>
                                                    </div>
                                                    <div class="col-lg-12 d-flex">
                                                        <div class="form-check me-3">
                                                            <input class="form-check-input" value="L" type="radio" name="jenis_kelamin" id="radioDefault1" <?= ($data['jenis_kelamin'] == "L" ? "checked" : "") ?>>
                                                            <label class="form-check-label" for="radioDefault1">
                                                                Laki-Laki
                                                            </label>
                                                        </div>
                                                        <div class="form-check">
                                                            <input class="form-check-input" value="P" type="radio" name="jenis_kelamin" id="radioDefault2" <?= ($data['jenis_kelamin'] == "P" ? "checked" : "") ?>>
                                                            <label class="form-check-label" for="radioDefault2">
                                                                Perempuan
                                                            </label>
                                                        </div>
                                                    </div>
                                                </div>
                                                <!-- end input group nama jenis kelamin-->          

                                                <!-- input group kelas -->
                                                <div class="row my-2">
                                                    <div class="col-lg-12">
                                                        <label for="">Kelas</label>
                                                    </div>
                                                    <div class="col-lg-12">
                                                        <select name="id_kelas" class="form-select" aria-label="Default select example">
                                                            <option>Pilih Kelas</option>
                                                            <?php
                                                       
                                                            $sql_eksekusi_kelas2 = mysqli_query($koneksi, $query);
                                                            while ($data_kelas = mysqli_fetch_array($sql_eksekusi_kelas2)) {
                                                            ?>
                                                                <option <?= $data['id_kelas'] == $data_kelas['id_kelas'] ? 'selected' : "" ?> value="<?= $data_kelas['id_kelas']; ?>">
                                                                    <?= $data_kelas['nama_kelas']; ?>
                                                                </option>
                                                            <?php } ?>
                                                        </select>
                                                    </div>
                                                </div>
                                                <!-- end input group kelas -->
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <input type="submit" value="Tambah" class="btn btn-success">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- akhir modal ubah -->

                            <!-- modal hapus  -->
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalHapus<?= $no; ?>">
                                <i class="bi bi-trash"></i>
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="ModalHapus<?= $no; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger text-light">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            Apakah kamu yakin ingin menghapus Siswa <b><?= $data['nama']; ?> </b>?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <a href="hapus_siswa.php?id_siswa=<?= $data['id_user']; ?>" class="btn btn-danger">Hapus</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- akhir modal hapus  -->
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</main>
<?php
include "../../includes/footer.php";
?>