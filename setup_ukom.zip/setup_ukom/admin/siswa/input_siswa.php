<?php
    session_start();

    if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
        header("location:../../index.php");
    }

    //Setup untuk koneksi, baseurl dan menu admin
    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";

    $nis            = $_POST['nis'];
    $nama           = $_POST['nama'];
    $email          = $_POST['email'];
    $password       = $_POST['password'];
    $jenis_kelamin  = $_POST['jenis_kelamin'];
    $id_kelas       = $_POST['id_kelas'];
    $role           = "user";

    $password_hashed = md5($password);

    $sql = "INSERT INTO tb_user (nis, nama, email, password, jenis_kelamin, id_kelas, role) VALUES ('$nis', '$nama', '$email', '$password_hashed', '$jenis_kelamin', '$id_kelas', '$role')";
    $sql_eksekusi = mysqli_query($koneksi, $sql);
    if($sql_eksekusi)
        {
            header("location:index.php");
        }
    else
        {
            header("location:".base_url."galat.php?pesan=gagalinputsiswa");
        }
    
?>