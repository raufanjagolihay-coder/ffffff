<?php
    session_start();

    if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
        header("location:../../index.php");
    }

    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";

    $id_siswa = $_GET['id_siswa'];

    $sql = "DELETE FROM tb_user WHERE id_user='$id_siswa'";
    $sql_eksekusi = mysqli_query($koneksi, $sql);
    if($sql_eksekusi)
        {
            header("location:index.php");
        }
    else
        {
            header("location:".base_url."galat.php");
        }
?>