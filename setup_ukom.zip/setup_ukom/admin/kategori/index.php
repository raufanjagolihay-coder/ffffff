<?php
session_start();

//Pengecekan Jika tidak ada Session role atau rolenya selain admin
//Maka di kick ke halaman landing page
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../../index.php");
}

$_SESSION['menu'] = "kategori";
//Setup untuk koneksi, baseurl dan menu admin
include "../../includes/koneksi.php";
include "../../includes/baseurl.php";
include "../../includes/navbar_admin.php";
?>

<main class="flex-fill">
    <div class="container py-3">
        <h5>Manajemen Kategori</h5>
        <hr>

        <!-- TOMBOL TAMBAH -->
        <!-- Button trigger modal -->
        <button type="button" class="btn btn-success mb-3" data-bs-toggle="modal" data-bs-target="#ModalTambah">
            <i class="bi bi-plus-lg"></i>Tambah Kategori
        </button>

        <!-- Modal -->
        <div class="modal fade" id="ModalTambah" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <form action="input_kategori.php" method="post">
                        <div class="modal-header bg-success text-light">
                            <h1 class="modal-title fs-5" id="exampleModalLabel">Tambahkan kategori</h1>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="row">
                                <div class="col-lg-12">
                                    <label for="">Nama Kategori</label>
                                    <input type="text" name="nama_kategori" id="" class="form-control">
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                            <input type="submit" value="Tambah" class="btn btn-success">
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- AKHIR TOMBOL TAMBAH -->

        <table class="table table-striped">
            <thead class="table-dark">
                <tr>
                    <th>No.</th>
                    <th>Nama Kategori</th>
                    <th>Waktu Dibuat</th>
                    <th>Tindakan</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql = "SELECT * FROM tb_kategori";
                $sql_eksekusi = mysqli_query($koneksi, $sql);
                $no = 1;
                while ($data = mysqli_fetch_array($sql_eksekusi)) {
                ?>
                    <tr>
                        <td><?= $no++; ?></td>
                        <td><?= $data['nama_kategori']; ?></td>
                        <td><?= $data['created_at']; ?></td>
                        <td>
                            <!-- modal ubah  -->
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-sm btn-warning text-light " data-bs-toggle="modal" data-bs-target="#ModalUbah<?= $no; ?>">
                                <i class="bi bi-pencil-square"></i>
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="ModalUbah<?= $no; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <form action="update_Kategori.php" method="post">
                                            <div class="modal-header bg-warning ">
                                                <h1 class="modal-title fs-5" id="exampleModalLabel">Tambahkan kategori</h1>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <div class="modal-body">
                                                <div class="row">
                                                    <div class="col-lg-12">
                                                        <label for="">Nama kategori</label>
                                                        <input type="hidden" name="id_kategori" id="" class="form-control" value="<?=  $data['id_kategori']; ?>">
                                                        <input type="text" name="nama_kategori" id="" class="form-control" value="<?=  $data['nama_kategori']; ?>">
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="modal-footer">
                                                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                <input type="submit" value="Ubah" class="btn btn-warning">
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <!-- akhir modal ubah -->

                            <!-- modal hapus  -->
                            <!-- Button trigger modal -->
                            <button type="button" class="btn btn-sm btn-danger" data-bs-toggle="modal" data-bs-target="#ModalHapus<?= $no; ?>">
                                <i class="bi bi-trash"></i>
                            </button>

                            <!-- Modal -->
                            <div class="modal fade" id="ModalHapus<?= $no; ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                <div class="modal-dialog">
                                    <div class="modal-content">
                                        <div class="modal-header bg-danger text-light">
                                            <h1 class="modal-title fs-5" id="exampleModalLabel">Modal title</h1>
                                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                        </div>
                                        <div class="modal-body">
                                            Apakah kamu yakin ingin menghapus kategori <b><?= $data['nama_kategori']; ?> </b>?
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                                            <a href="hapus_kategori.php?id_kategori=<?= $data['id_kategori']; ?>" class="btn btn-danger">Hapus</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- akhir modal hapus  -->
                        </td>
                    </tr>
                <?php
                }
                ?>
            </tbody>
        </table>
    </div>
</main>
<?php
include "../../includes/footer.php";
?>