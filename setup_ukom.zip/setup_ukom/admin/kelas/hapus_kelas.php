<?php
    session_start();

    if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
        header("location:../../index.php");
    }

    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";

    $id_kelas = $_GET['id_kelas'];

    $sql = "DELETE FROM tb_kelas WHERE id_kelas='$id_kelas'";
    $sql_eksekusi = mysqli_query($koneksi, $sql);
    if($sql_eksekusi)
        {
            header("location:index.php");
        }
    else
        {
            header("location:".base_url."galat.php");
        }
?>