<?php
    session_start();

    if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
        header("location:../../index.php");
    }

    //Setup untuk koneksi, baseurl dan menu admin
    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";

    $nama_kelas   = $_POST['nama_kelas'];
    $tahun_ajaran   = $_POST['tahun_ajaran'];

    $sql = "INSERT INTO tb_kelas (nama_kelas, tahun_ajaran) VALUES ('$nama_kelas', '$tahun_ajaran')";
    $sql_eksekusi = mysqli_query($koneksi, $sql);
    if($sql_eksekusi)
        {
            header("location:index.php");
        }
    else
        {
            header("location:".base_url."galat.php?pesan=gagalinputkelas");
        }
    
?>