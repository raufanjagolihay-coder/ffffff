<?php
session_start();

//Pengecekan Jika tidak ada Session role atau rolenya selain admin
//Maka di kick ke halaman landing page
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../index.php");
}

$_SESSION['menu'] = "beranda";
//Setup untuk koneksi, baseurl dan menu admin
include "../includes/koneksi.php";
include "../includes/baseurl.php";
include "../includes/navbar_admin.php";
?>

<main class="flex-fill">
    <div class="container py-3">
        <h5>Panel Utama</h5>
        <hr>
        <div class="row g-3">

            <div class="col-lg-3 col-sm-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Total Kelas</h5>
                        <h2>10</h2>
                        <a href="#" class="btn btn-primary mt-2 form-control">Lihat Kelas <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Total Siswa</h5>
                        <h2>1000</h2>
                        <a href="#" class="btn btn-primary mt-2 form-control">Lihat Siswa <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Total Kategori</h5>
                        <h2>4</h2>
                        <a href="#" class="btn btn-primary mt-2 form-control">Lihat Kategori <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
            </div>

            <div class="col-lg-3 col-sm-6">
                <div class="card h-100">
                    <div class="card-body">
                        <h5 class="card-title">Total Aspirasi</h5>
                        <h2>2400</h2>
                        <a href="#" class="btn btn-primary mt-2 form-control">Lihat Aspirasi <i class="bi bi-arrow-right"></i></a>
                    </div>
                </div>
            </div>

        </div>
    </div>
</main>
<?php
include "../includes/footer.php";
?>