<link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
<!-- Awal Navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
        <div class="container">
            <a href="../" class="navbar-brand fw-bold">Asis</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a href="" class="nav-link">Fitur</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Tentang</a></li>
                    <li class="nav-item"><a href="" class="btn btn-light text-primary">Masuk</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- AKhir Navbar -->
<!-- Awal Konten -->
     <div class="container vh-custom d-flex justify-content-center align-items-center">
        <section class="">
        <div class="">
            <div class="row d-flex justify-content-center align-items-center">
            <div class="col-md-9 col-lg-6 col-xl-5">
                <img src="https://img.freepik.com/vektor-gratis/ilustrasi-hari-sepeda-dunia-datar_23-2149392756.jpg"
                class="img-fluid" alt="Sample image">
            </div>
            <div class="col-md-8 col-lg-6 col-xl-4 offset-xl-1">
                <form action="cek_login.php" method="POST">
                <!-- Email input -->
                <div data-mdb-input-init class="form-outline mb-4">
                    <input type="email" name="email" id="form3Example3" class="form-control form-control-lg"
                    placeholder="Enter a valid email address" />
                    <label class="form-label" for="form3Example3">Nama Pengguna</label>
                </div>

                <!-- Password input -->
                <div data-mdb-input-init class="form-outline mb-3">
                    <input type="password" name="password" id="form3Example4" class="form-control form-control-lg"
                    placeholder="Enter password" />
                    <label class="form-label" for="form3Example4">Katasandi</label>
                </div>


                <div class="text-center text-lg-start mt-4 pt-2">
                    <input type="submit" data-mdb-button-init data-mdb-ripple-init class="btn btn-primary btn-lg"
                    style="padding-left: 2.5rem; padding-right: 2.5rem;" VALUE='Masuk'>
                    
                </div>

                </form>
            </div>
            </div>
        </div>
        </section>
     </div>
    <!-- Akhir Konten -->