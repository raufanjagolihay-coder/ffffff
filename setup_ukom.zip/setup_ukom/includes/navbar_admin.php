<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="<?= base_url ?>bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="<?= base_url ?>bootstrap-icons/bootstrap-icons.css">
</head>

<body class="d-flex flex-column min-vh-100">
  <!-- Awal Navbar -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-primary shadow">
    <div class="container">
      <a href="<?= base_url."admin"; ?>" class="navbar-brand fw-bold">Asis</a>
      <div class="collapse navbar-collapse">
        <ul class="navbar-nav me-auto">
          <li class="nav-item"><a href="<?= base_url."admin/kelas"; ?>" class="nav-link <?php if($_SESSION['menu']=="kelas") { echo "active"; }; ?>">Kelas</a></li>
          <li class="nav-item"><a href="<?= base_url."admin/siswa"; ?>" class="nav-link <?php if($_SESSION['menu']=="siswa") { echo "active"; }; ?>">Siswa</a></li>
          <li class="nav-item"><a href="<?= base_url."admin/kategori"; ?>" class="nav-link <?php if($_SESSION['menu']=="kategori") { echo "active"; }; ?>">Kategori</a></li>
          <li class="nav-item"><a href="<?= base_url."admin/aspirasi"; ?>" class="nav-link <?php if($_SESSION['menu']=="aspirasi") { echo "active"; }; ?>">Aspirasi</a></li>
          <li class="nav-item"><a href="<?= base_url."admin/feedback"; ?>" class="nav-link <?php if($_SESSION['menu']=="feedback") { echo "active"; }; ?>">Umpan Balik</a></li>
        </ul>
        <ul class="navbar-nav ms-auto">
          <li class="nav-item"><a href="<?= base_url."login/logout.php"; ?>" class="btn btn-danger text-light">Keluar</a></li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- AKhir Navbar -->
   