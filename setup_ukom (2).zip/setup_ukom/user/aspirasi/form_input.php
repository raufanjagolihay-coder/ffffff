<?php
session_start();

//Pengecekan Jika tidak ada Session role atau rolenya selain admin
//Maka di kick ke halaman landing page
if (!isset($_SESSION['role']) || $_SESSION['role'] != "user") {
    header("location:../../index.php");
}

//Setup untuk koneksi, baseurl dan menu admin
$_SESSION['menu'] = "aspirasi";
include "../../includes/koneksi.php";
include "../../includes/baseurl.php";
include "../../includes/navbar_user.php";
?>

<main class="flex-fill">
    <div class="container py-3">
        <a href="index.php" class="btn btn-primary me-2 btn-sm"><i class="bi bi-arrow-left"></i></a>
        <span>Sampaikan Aspirasimu Disini!</span>
        <hr>
        <form action="input_aspirasi.php" method="post" enctype="multipart/form-data">
            <div class="row">
                <div class="col-lg-4">
                    <label for="">Pilih Kategori</label>
                    <select name="id_kategori" class="form-select mt-2">
                        <option value="">Pilih Kategori</option>
                        <?php
                        $sql = "SELECT * FROM tb_kategori";
                        $sql_eksekusi = mysqli_query($koneksi, $sql);
                        while ($data = mysqli_fetch_array($sql_eksekusi)) {
                        ?>
                            <option value="<?= $data['id_kategori'] ?>">
                                <?= $data['nama_kategori'] ?>
                            </option>
                        <?php
                        }
                        ?>
                    </select>
                </div>
                <div class="col-lg-8">
                    <label for="">Lokasi</label>
                    <input type="text" name="lokasi" id="" class="form-control mt-2" placeholder="Tulis lokasi singkat">
                </div>
            </div>

            <div class="row mt-2">
                <div class="col-lg-8">
                    <label for="">Upload Foto Pendukung (opsional)</label>
                    <input type="file" name="foto" id="" class="form-control mt-2" accept="image/*">
                </div>
            </div>

            <div class="row mt-4">
                <div class="col-lg-12">
                    <label for="">Tulis Secara Lengkap Aspirasimu</label>
                    <textarea name="isi_aspirasi" id="" rows="4" class="form-control mt-2" placeholder="Tulis secara lengkap dan jelas mengenai aspirasi yang ingin kamu sampaikan"></textarea>
                </div>
            </div>

            <div class="row mt-3">
                <div class="col-lg-4">
                    <a href="index.php" class="btn btn-danger me-3">Batal</a>

                    <input type="submit" value="Buat Aspirasi" class="btn btn-success">
                </div>
            </div>
        </form>
    </div>
</main>
<?php
include "../../includes/footer.php";
?>