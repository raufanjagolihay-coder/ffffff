<?php
    session_start();

    //Pengecekan Jika tidak ada Session role atau rolenya selain admin
    //Maka di kick ke halaman landing page
    if(!isset($_SESSION['role']) || $_SESSION['role'] != "user") {
        header("location:../../index.php");
    }

    //Setup untuk koneksi, baseurl dan menu admin
    $_SESSION['menu'] = "aspirasi";
    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";
    include "../../includes/navbar_user.php";
?>

<main class="flex-fill">
<div class="container py-3">
    <h5>Manajemen Aspirasi</h5><hr>
    <a href="form_input.php" class="btn btn-success">Buat Aspirasi</a>
</div>
</main>
<?php
    include "../../includes/footer.php";
?>