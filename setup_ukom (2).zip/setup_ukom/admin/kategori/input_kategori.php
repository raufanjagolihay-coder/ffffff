<?php
    session_start();

    if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
        header("location:../../index.php");
    }

    //Setup untuk koneksi, baseurl dan menu admin
    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";

    $nama_kategori   = $_POST['nama_kategori'];

    $sql = "INSERT INTO tb_kategori (nama_kategori) VALUES ('$nama_kategori')";
    $sql_eksekusi = mysqli_query($koneksi, $sql);
    if($sql_eksekusi)
        {
            header("location:index.php");
        }
    else
        {
            header("location:".base_url."galat.php?pesan=gagalinputkelas");
        }
    
?>