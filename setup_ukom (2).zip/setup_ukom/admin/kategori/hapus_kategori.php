<?php
    session_start();

    if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
        header("location:../../index.php");
    }

    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";

    $id_kategori = $_GET['id_kategori'];

    $sql = "DELETE FROM tb_kategori WHERE id_kategori='$id_kategori'";
    $sql_eksekusi = mysqli_query($koneksi, $sql);
    if($sql_eksekusi)
        {
            header("location:index.php");
        }
    else
        {
            header("location:".base_url."galat.php");
        }
?>