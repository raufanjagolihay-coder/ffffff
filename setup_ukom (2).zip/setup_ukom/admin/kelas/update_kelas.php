<?php
    session_start();

    if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
        header("location:../../index.php");
    }

    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";

    $id_kelas = $_POST['id_kelas'];
    $nama_kelas = $_POST['nama_kelas'];
    $tahun_ajaran = $_POST['tahun_ajaran'];

    $sql = "UPDATE tb_kelas SET nama_kelas='$nama_kelas', tahun_ajaran='$tahun_ajaran' WHERE id_kelas = '$id_kelas'";
    $sql_eksekusi = mysqli_query($koneksi, $sql);
    if($sql_eksekusi)
        {
            header("location:index.php");
        }
    else
        {
            header("location:".base_url."galat.php");
        }
?>