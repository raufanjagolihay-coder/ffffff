<?php
    session_start();

    if(!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
        header("location:../../index.php");
    }

    include "../../includes/koneksi.php";
    include "../../includes/baseurl.php";

    $id_siswa       = $_POST['id_siswa'];
    $nis            = $_POST['nis'];
    $nama           = $_POST['nama'];
    $email          = $_POST['email'];
    $jenis_kelamin  = $_POST['jenis_kelamin'];
    $id_kelas       = $_POST['id_kelas'];
    $role           = "siswa";

    if($_POST['password']==null)
        {
            $password_hash = $_POST['password_lama'];
        }
    else
        {
            $password_hash = md5($_POST['password']);
        }

    $sql = "UPDATE tb_user SET nis='$nis', nama='$nama', email='$email', 
    password='$password_hash', jenis_kelamin='$jenis_kelamin', id_kelas='$id_kelas' 
    WHERE id_user = '$id_siswa'";
    $sql_eksekusi = mysqli_query($koneksi, $sql);
    if($sql_eksekusi)
        {
            header("location:index.php");
        }
    else
        {
            header("location:".base_url."galat.php");
        }
?>