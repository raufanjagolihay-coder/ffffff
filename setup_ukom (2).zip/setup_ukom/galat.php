<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kegagalan Sistem</title>
    <?php
    include "includes/baseurl.php";
    ?>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons/bootstrap-icons.css">
</head>

<body class="bg-primary">
    <?php

    if (!isset($_GET['pesan'])) {
        $judul  = "Kesalahan Sistem";
        $isi    = "Perubahan Tidak Disimpan";
        $link   = base_url;
        $ikon   = "";
        $tombol = "Landing Page";
        $wtom   = "btn-danger";
    }
    else if ($_GET['pesan'] == "gagallogin")
    {
        $judul  = "Email dan Kata Sandi Salah!";
        $isi    = "Kombinasi Email dan Sandi tidak ditemukan, pastikan email dan kata sandi ditulis dengan benar";
        $link   = base_url."login/";
        $ikon   = "bi-lock-fill";
        $tombol = "Kembali ke Halaman Masuk";
        $wtom   = "btn-warning";
    }
    else if ($_GET['pesan'] == "gagalinputkelas")
    {
        $judul  = "Gagal Input Kelas";
        $isi    = "Terdapat kesalahan pada sistem, kami akan segera memperbaiki kesalahan ini";
        $link   = base_url."admin/kelas";
        $ikon   = "bi-exclamation-diamond";
        $tombol = "Kembali ke Halaman Kelas";
        $wtom   = "btn-danger";
    }

    ?>
    <div class="d-flex justify-content-center align-items-center vh-100">
        <div class="bg-light shadow rounded p-5 text-center">
            <h2><i class="bi <?= $ikon; ?>"></i> <?= $judul; ?></h2>
            <p><?= $isi; ?></p>
            <a href="<?= $link; ?>" class="btn <?= $wtom; ?> mt-3"><?= $tombol; ?></a>
        </div>
    </div>
</body>

</html>