
<footer class="py-3 text-center bg-primary text-light">
    <small>© 2026 ASIS - Aspirasi Siswa</small>
</footer>


<script src="<?= base_url."bootstrap/js/bootstrap.bundle.js"; ?>"></script>
</body>
</html>