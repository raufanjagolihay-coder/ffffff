CREATE TABLE tb_aspirasi (
    id_aspirasi INT AUTO_INCREMENT PRIMARY KEY,
    id_user
);