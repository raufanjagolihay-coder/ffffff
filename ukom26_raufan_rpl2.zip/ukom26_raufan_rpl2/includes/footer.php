
<footer class="py-3 text-center bg-success shadow text-light fw-medium">
    <small>2026 - Bilang Aja!</small>
</footer>


    <script src="<?= base_url . "bootstrap/js/bootstrap.bundle.js" ?>"></script>
</body>
</html>