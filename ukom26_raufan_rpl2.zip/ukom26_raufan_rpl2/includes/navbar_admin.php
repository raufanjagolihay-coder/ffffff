<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="../bootstrap-icons/bootstrap.icons.css">

    <style></style>
</head>

<body class="d-flex flex-column min-vh-100">
    <!-- Awal navbar -->
    <nav class="bo navbar navbar-expand-lg navbar-dark bg-success shadow">
        <div class="container">
            <a href="" class="navbar-brand fw-bold">Bilang Aja!</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav me-auto">
                    <li class="nav-item"><a href="" class="nav-link">Kelas</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Siswa</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Kategori</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Aspirasi</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Umpan balik</a></li>
                </ul>
                <ul class="navbar-nav ms-auto">
                     <li class="nav-item"><a href="login/login.php" class="btn btn-danger text-light">Masuk</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Akhir navbar -->

</body>

</html>