<?php

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Aspirasi</title>
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css">
    <link rel="stylesheet" href="bootstrap-icons/bootstrap-icons.css">
    
</head>



<body>
    <!-- Awal navbar -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-primary fixed-top shadow">
        <div class="container">
            <a href="" class="navbar-brand fw-bold">Bilang Aja!</a>
            <div class="collapse navbar-collapse">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a href="" class="nav-link">Fitur</a></li>
                    <li class="nav-item"><a href="" class="nav-link">Tentang</a></li>
                    <li class="nav-item"><a href="login/login.php" class="btn btn-light text-primary">Masuk</a></li>
                </ul>
            </div>
        </div>
    </nav>
    <!-- Akhir navbar -->

    <!-- hero section -->
     <section class="hero text-center text-light bg-secondary min-vh-100 d-flex align-items-center pt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <h1 class="display-4 fw-bold mt-3">Bilang Aja Kebutuhanmu!</h1>
                    <p class="lead mt-3">Aplikasi yang menampung aspirasi siswa terkait sarana dan prasarana sekolah, guna membangun dan melengkapi fasilitas yang</p>
                    <a href="login/cuba.php" class="btn btn-light btn-lg fw-medium">Bilang Sekarang <i class="bi bi-arrow-right"></i> </a>
                </div>
            </div>
        </div>
     </section>
     <!-- hero section -->
</body>

</html>