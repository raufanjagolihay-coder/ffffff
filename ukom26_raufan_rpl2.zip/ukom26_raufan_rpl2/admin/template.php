<?php
session_start();

// pengecekan jika tidak terdapat session role atau rolenya selain admin
// maka di kick ke halaman landing page
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../index.php");
}

// set up  untuk koneksi, baseurl dan menu admin
include "../includes/koneksi.php";
include "../includes/baseurl.php";
include "../includes/navbar_admin.php";
?>
<main class="flex-fill">
    <div class="container py-3">
        <h5>Panel Utama</h5>
        <hr>
    </div>
</main>

<?php 
    include "../includes/footer.php";
?>