<?php
session_start();

// pengecekan jika tidak terdapat session role atau rolenya selain admin
// maka di kick ke halaman landing page
if (!isset($_SESSION['role']) || $_SESSION['role'] != "admin") {
    header("location:../index.php");
}

// set up  untuk koneksi, baseurl dan menu admin
include "../includes/koneksi.php";
include "../includes/baseurl.php";
include "../includes/navbar_admin.php";
?>
<main class="flex-fill">
    <div class="container py-3">
        <h5>Panel Utama</h5>
        <hr>
        <div class="row g-3">
            <div class="col-lg-3 col-sm-6 ">
                <div class="card vh-100">
                    <div class="card-body">
                        <h5 class="card-title">Total Kelas</h5>
                        <h2>10</h2>
                        <a href="#" class="btn btn-primary mt-2 form-control">Lihat Kelas <i class="bi bi-arrow"></i> </a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                 <div class="card vh-100">
                    <div class="card-body">
                        <h5 class="card-title">Total Siswa</h5>
                        <h2>500</h2>
                        <a href="#" class="btn btn-primary mt-2 form-control">Lihat Siswa</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                 <div class="card vh-100">
                    <div class="card-body">
                        <h5 class="card-title">Total Kategori</h5>
                        <h2>3</h2>
                        <a href="#" class="btn btn-primary mt-2 form-control">Lihat Kategori</a>
                    </div>
                </div>
            </div>
            <div class="col-lg-3 col-sm-6">
                <div class="card vh-100">
                    <div class="card-body">
                        <h5 class="card-title">Total Umpan Balik</h5>
                        <h2>50  </h2>
                        <a href="#" class="btn btn-primary mt-2 form-control">Lihat umpan balik</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php
include "../includes/footer.php";
?>