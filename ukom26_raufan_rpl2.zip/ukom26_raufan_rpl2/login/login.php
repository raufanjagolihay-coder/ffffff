<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <title>Login</title>
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

  <style>
    body {
      min-height: 100vh;
      background: linear-gradient(135deg, #556b2f, #90ee90, #dff5e1);
    }

    .login-card {
      border-radius: 1rem;
      background-color: #ffffff;
    }
  </style>
</head>

<body class="d-flex align-items-center justify-content-center">

  <div class="container">
    <div class="row justify-content-center">
      <div class="col-md-5 col-lg-4">
        <div class="card login-card shadow">
          <div class="card-body p-4">
            <h3 class="text-center mb-2">Login</h3>
            <p class="text-center text-muted">Silahkan login terlebih dahulu</p>

            <form action="cek_login.php" method="POST">
              <div class="mb-3">
                <label class="form-label">Email</label>
                <input type="email" name="email" class="form-control" placeholder="masukkan email" required>
              </div>

              <div class="mb-3">
                <label class="form-label">Password</label>
                <input type="password" name="password" class="form-control" placeholder="masukkan password" required>
              </div>

              <input type="submit" class="btn btn-outline-success col-lg-12" value="Masuk">
            </form>

            <p class="text-center mt-3 mb-0">
              Belum punya akun? <a href="#">Daftar</a>
            </p>
          </div>
        </div>
      </div>
    </div>
  </div>

</body>

</html>