<?php
session_start();
$_SESSION['menu'] = "Beranda";
include "../includes/header.php";
?>

<!-- Awal Konten -->
<div class="container vh-custom d-flex justify-content-center align-items-center">
    <section class="w-100">
        <div class="container-fluid">
            <div class="row justify-content-center align-items-center">

                <!-- Gambar Samping -->
                <div class="col-md-6 col-lg-6 mb-4 mb-md-0 text-center">
                    <img 
                        src="../sepeda3.jpg"  
                        class="img-fluid rounded-4 shadow" 
                        alt="Login Illustration"
                        style="max-width: 90%;"
                    >
                </div>

                <!-- Form Login -->
                <div class="col-md-6 col-lg-5">
                    <div class="card shadow-lg border-0 rounded-4 p-4 ">
                        <h3 class="text-center mb-4 ">Selamat Datang Di Login Admin</h3>
                        <form action="cek_login.php" method="POST">
                            
                            <!-- Input Email -->
                            <div class="form-outline mb-4">
                                <label class="form-label" for="name">Username</label>
                                <input 
                                    type="text" 
                                    id="form3Example3" 
                                    name="username"
                                    class="form-control form-control-lg"
                                    placeholder="Enter username" 
                                    required
                                >
                            </div>
                           
                            <!-- Input Password -->
                            <div class="form-outline mb-3">
                                <label class="form-label" for="password">Kata Sandi</label>
                                <input 
                                    type="password" 
                                    id="password" 
                                    name="password"
                                    class="form-control form-control-lg"
                                    placeholder="Enter password" 
                                    required
                                >
                            </div>

                            <!-- Tombol Login -->
                            <div class="text-center mt-4">
                                <button 
                                    type="submit" 
                                    class="btn btn-primary btn-lg w-100"
                                >
                                    Masuk
                                </button>
                            </div>
                        </form>

                        <!-- Link Tambahan -->
                        <div class="mt-4 text-center">
                            <p class="small">Belum punya akun? <a href="register.php">Daftar</a></p>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </section>
</div>
<!-- Akhir Konten -->

<?php include "../includes/footer.php"; ?>
